Simplejobscript Base Version 1.3

------------------------------------------------
#################################### LINKS

GET USEFUL ADD-ONS:
http://simplejobscript.com/all-products/

INSTALLATION GUIDE & DOCS:
http://simplejobscript.com/docs/

WORDPRESS HOSTING:
http://flyingwp.com

------------------------------------------------
#################################### GUIDE

INSTALLATION:

1. Copy content of "upload" folder to your server

2. Folder permissions should be all setup by default, writable by the web server.
   Try to open your website in browser, installer will test the permissions and tell you if you need to change them.
   Permission Rules: all folders should be 755, except: "_cache/", "_config/config.envs.php", "_tpl/", "uploads/", "blog/content", "sjs-admin/_tpl/_cache" - all these folders should be permitted to 777

3. Create database for your project and finish the installation in the browser. For the App Url, use your domain without http (eg. “domain.com” or “localhost”)

****************

problems with installation? Let us install the job board for you
https://simplejobscript.com/downloads/installation-service/

****************

