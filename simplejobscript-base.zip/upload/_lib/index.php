<?php
	header('Location: /');
	exit;
?>